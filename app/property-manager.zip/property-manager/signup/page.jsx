'use client';

import PropertyManagerSignup from '@/views/PropertyManagerSignup';

export default function PropertyManagerSignupPage() {
  return <PropertyManagerSignup />;
}

