'use client';

// This page is handled by the layout.jsx which wraps everything with Dashboard
// The Dashboard component handles all routing internally
export default function PropertyManagerCatchAll() {
  return null;
}

